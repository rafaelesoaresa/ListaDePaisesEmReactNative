import axios from 'axios';

const BASE_URL = 'https://restcountries.com/v3.1/';

const handleRequestError = (error) => {
  let errorMessage = 'Failed to fetch data. Please try again later.';

  if (error.response) {
    console.error('Request failed with status:', error.response.status);
    console.error('Response data:', error.response.data);
    errorMessage = `Request failed with status ${error.response.status}`;
  } else if (error.request) {
    console.error('No response received:', error.request);
    errorMessage = 'No response received from server. Please check your internet connection.';
  } else {
    console.error('Request setup failed:', error.message);
    errorMessage = 'Failed to setup request. Please try again later.';
  }

  throw new Error(errorMessage);
};

export const getAllCountries = async () => {
  try {
    const response = await axios.get(`${BASE_URL}all`);
    return response.data;
  } catch (error) {
    handleRequestError(error);
  }
};

export const getCountryByName = async (name) => {
  try {
    const response = await axios.get(`${BASE_URL}name/${name}`);
    return response.data;
  } catch (error) {
    handleRequestError(error);
  }
};

export const getCountryByAlphaCode = async (alphaCode) => {
  try {
    const response = await axios.get(`${BASE_URL}alpha/${alphaCode}`);
    return response.data;
  } catch (error) {
    handleRequestError(error);
  }
};

export const getCountriesByRegion = async (region) => {
  try {
    const response = await axios.get(`${BASE_URL}region/${region}`);
    return response.data;
  } catch (error) {
    handleRequestError(error);
  }
};

// Adicione mais funções para os outros endpoints da API conforme necessário
